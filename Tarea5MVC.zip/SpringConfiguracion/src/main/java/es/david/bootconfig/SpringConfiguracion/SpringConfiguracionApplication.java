package es.david.bootconfig.SpringConfiguracion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringConfiguracionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringConfiguracionApplication.class, args);
	}

}
