package es.david.bootconfig.SpringConfiguracion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringConfiguracionApplicationTests {

	@Test
	void contextLoads() {
	}

}
